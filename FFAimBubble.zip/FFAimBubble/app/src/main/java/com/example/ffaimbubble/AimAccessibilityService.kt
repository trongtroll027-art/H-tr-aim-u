package com.example.ffaimbubble

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.view.accessibility.AccessibilityEvent

class AimAccessibilityService : AccessibilityService() {

    companion object {
        var instance: AimAccessibilityService? = null
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    override fun onDestroy() {
        super.onDestroy()
        instance = null
    }

    fun dragAim(dx: Float, dy: Float) {
        if (dx == 0f && dy == 0f) return
        val path = Path()
        val res = resources.displayMetrics
        val cx = res.widthPixels / 2f
        val cy = res.heightPixels / 2f
        path.moveTo(cx, cy)
        path.lineTo(cx + dx, cy + dy)
        val stroke = GestureDescription.StrokeDescription(path, 0, 20)
        val gesture = GestureDescription.Builder().addStroke(stroke).build()
        dispatchGesture(gesture, null, null)
    }
}